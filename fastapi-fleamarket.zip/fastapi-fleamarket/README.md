## フリマAPI 9 章までのコード

コードを実行するには以下のコマンドでライブラリをインストールして下さい

```
pip install -r requirements.txt
```
